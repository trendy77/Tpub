<?php

namespace App\Http\Controllers\General;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SController extends Controller {
	
	public function index() {
		
	}
}