<?php

return  [
    'TMDB_API' => env('TMDB_API'),
    'TMDB_LANG' => env('TMDB_LANG')
];