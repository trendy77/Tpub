<div class="blocks--head"><h1 class="title">Pages</h1></div>
<div class="blocks--body">
    <ul class="block--list">
    	<li class="block--item"><a class="block--link" href="{{ route('admin.movies.index') }}">Movies</a></li>	
    	<li class="block--item"><a class="block--link" href="{{ route('admin.persons.index') }}">Persons</a></li>	
    	<li class="block--item"><a class="block--link" href="{{ route('admin.news.index') }}">News</a></li>
        <li class="block--item"><a class="block--link" href="{{ route('admin.nav.index') }}">Navigation</a></li>
        <li class="block--item"><a class="block--link" href="{{ route('admin.pages.index') }}">Pages</a></li>
    	<li class="block--item"><a class="block--link" href="{{ route('admin.users.index') }}">Users</a></li>	
    	<li class="block--item"><a class="block--link" href="{{ route('admin.slider.index') }}">Slider</a></li>		
    	<li class="block--item"><a class="block--link" href="{{ route('admin.settings.index') }}">Settings</a></li>	
    </ul>
</div>