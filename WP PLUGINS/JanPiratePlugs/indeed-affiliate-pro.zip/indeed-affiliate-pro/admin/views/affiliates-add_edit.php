<div class="uap-wrapper">
	<div class="uap-stuffbox">
		<h3 class="uap-h3"><?php _e('Add/Edit Affiliate', 'uap');?></h3>
		<div class="inside">
			<?php echo $data['output'];?>
		</div>
	</div>
</div>


</div><!-- end of uap-dashboard-wrap -->	