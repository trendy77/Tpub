	</div>
	<div class="uap-clear"></div>
</div>
<div class="uap-user-page-footer">
	<?php echo do_shortcode($data['footer_content']);?>
</div>
</div>