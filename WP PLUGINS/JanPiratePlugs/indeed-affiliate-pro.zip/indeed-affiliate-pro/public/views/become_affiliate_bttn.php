<div class="uap-become-affiliate-wrapp">
	<button class="uap-become-affiliate-bttn" onclick="uap_become_affiliate_public();"><?php _e('Become an Affiliate', 'uap');?></button>
</div>