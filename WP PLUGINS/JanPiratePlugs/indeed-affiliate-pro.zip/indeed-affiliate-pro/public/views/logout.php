<style><?php echo @$data['metas']['login_custom_css'];?></style>
<div class="uap-logout-wrap <?php echo @$data['metas']['uap_login_template'];?>">
	<a href="<?php echo @$data['logout_link'];?>"><?php echo @$data['logout_label'];?></a>
</div>	