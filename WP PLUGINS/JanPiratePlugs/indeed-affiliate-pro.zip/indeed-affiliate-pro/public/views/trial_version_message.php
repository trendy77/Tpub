<div class="uap-public-trial-version">
	<?php _e('This is a Trial Version of <strong>Ultimate Affiliate Pro</strong> plugin. Please add your purchase code into Licence section to enable the Full Ultimate Affiliate Pro Version.', 'uap');?>
</div>