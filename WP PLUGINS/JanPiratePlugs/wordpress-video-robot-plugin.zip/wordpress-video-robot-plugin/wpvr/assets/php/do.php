<?php
	
		if( isset( $_GET['get_wake_hours_runs'] ) ){
			
			echo "WE CONTROL YOU !";
			
			
			exit;
		}


?>