<?php

	$vs = array();

	//require_once( 'helper.php' );
	require_once( 'basics.php' );
	require_once( 'helpers.php' );
	require_once( 'types.php' );
	require_once( 'functions.php' );

	$wpvr_found_services[ $vs['id'] ] = $vs ;