<?php
	
	//add_filter('wpvr_extend_video_query_injection', 'wpvr_escape_injection' , 100 , 2 );
	//function wpvr_escape_injection( $getOut , $query ){
	//	/* return true to escape WPVR imported videos injection */
	//}
	