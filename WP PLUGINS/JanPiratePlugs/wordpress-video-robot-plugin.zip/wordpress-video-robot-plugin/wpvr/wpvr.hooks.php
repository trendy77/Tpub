<?php

	require_once( 'hooks/wpvr.hooks.assets.php');
	require_once( 'hooks/wpvr.hooks.core.php');
	require_once( 'hooks/wpvr.hooks.custom.php');
	require_once( 'hooks/wpvr.hooks.menus.php');
	require_once( 'hooks/wpvr.hooks.notices.php');
	require_once( 'hooks/wpvr.hooks.shortcodes.php');
	require_once( 'hooks/wpvr.hooks.rewrite.php');
	require_once( 'wpvr.custom.hooks.php');
