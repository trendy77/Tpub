<?php
	
	// function wpvr_get_meminfo() {
	// 	$data    = explode( "\n", file_get_contents( "/proc/meminfo" ) );
	// 	$meminfo = array();
	// 	foreach ( (array) $data as $line ) {
	// 		list( $key, $val ) = explode( ":", $line );
	//
	// 		$val             = str_replace( ' kB', '', trim( $val ) );
	// 		$meminfo[ $key ] = ceil( $val / 1000 );
	// 	}
	// 	// Memory in Mo
	// 	return array(
	// 		'total' => $meminfo['MemTotal'],
	// 	);
	// }
	//
	// $mm = wpvr_get_meminfo();
	// d( $mm );
	
	
	