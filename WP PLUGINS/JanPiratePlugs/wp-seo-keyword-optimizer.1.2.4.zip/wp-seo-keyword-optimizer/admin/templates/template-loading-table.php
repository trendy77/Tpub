<div class="wsko_box_wrapper">
	<i class="fa fa-spinner fa-spin fa-5x"></i>Loading Table
</div>