<div class="wsko_no_cache_wrapper">
<i class="fa fa-times" style="font-size:80px; color:#ddd;" aria-hidden="true"></i></br>
<span>No Data available</span>
</div>