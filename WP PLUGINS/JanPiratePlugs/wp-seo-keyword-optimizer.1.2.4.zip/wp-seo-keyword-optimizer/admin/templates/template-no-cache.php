<div class="wsko_no_cache_wrapper">
<i class="fa fa-retweet" style="font-size:80px; color:#ddd;" aria-hidden="true"></i></br>
<a class="wsko_update_cache_btn button" style="margin:10px;" href="#"><i class="fa fa-spinner fa-pulse" style="display:none;"></i> Update Cache manually</a>

</div>