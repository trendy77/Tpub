<?php
if (!defined('WP_UNINSTALL_PLUGIN'))
{
	exit; // Exit if accessed directly
}

$wsko_data = get_option('wsko_init');
if (isset($wsko_data['clean_uninstall']) && $wsko_data['clean_uninstall'])
{
	global $wpdb;

	delete_option('wsko_init');
	wp_clear_scheduled_hook('wsko_cache_keywords');
	$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . 'wsko_cache');
	$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . 'wsko_cache_rows');
}
?>