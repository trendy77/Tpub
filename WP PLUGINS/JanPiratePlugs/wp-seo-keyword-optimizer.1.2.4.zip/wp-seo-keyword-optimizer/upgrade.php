<?php
global $wsko_data;

if (!$wsko_data || !is_array($wsko_data))
{
	wsko_install_plugin();
	$wsko_data = array(
		'version' => WSKO_VERSION,
		'token' => false,
		'add_bootstrap' => true,
		'add_fontawesome' => true,
		'add_moment' => true,
		'add_bootstrap_datepicker' => true,
		'add_datatables' => true,
		'add_google_chart' => true,
		'activate_post_widget' => true,
		'activate_caching' => true,
	);
	
	if ($wsko_data)
		update_option('wsko_init', $wsko_data);
	else
		add_option('wsko_init', $wsko_data);
}
else
{
	if (version_compare($wsko_data['version'], WSKO_VERSION, '<'))
	{
		if (version_compare($wsko_data['version'], '1.1.3', '<'))
		{
			delete_option('wsko_init');
			
			delete_option('bv_add_bootstrap');
			delete_option('bv_add_fontawesome');
			delete_option('bv_add_moment');
			delete_option('bv_add_bootstrap_datepicker');
			delete_option('bv_add_datatables');
			delete_option('bv_add_google_chart');
			
			delete_option('wsko_activate_post_widget');
			
			delete_option('wsko_keyword_max_time');
			delete_option('wsko_keyword_limit_main');
			delete_option('wsko_keyword_limit_dashboard');
			delete_option('wsko_keyword_limit_post');
		}
		
		if (version_compare($wsko_data['version'], '1.2.4', '<='))
		{
			wp_clear_scheduled_hook('wsko_cache_keywords');
			wp_schedule_event(wsko_get_midnight(time()), 'daily', 'wsko_cache_keywords');
		}
			
		$wsko_data = array(
			'version' => WSKO_VERSION,
			'token' => false,
			'add_bootstrap' => true,
			'add_fontawesome' => true,
			'add_moment' => true,
			'add_bootstrap_datepicker' => true,
			'add_datatables' => true,
			'add_google_chart' => true,
			'activate_post_widget' => true,
			'activate_caching' => true,
		);
		
		if (get_option('wsko_init'))
			update_option('wsko_init', $wsko_data);
		else
			add_option('wsko_init', $wsko_data);
	}
}

$token = ($wsko_data && isset($wsko_data['token'])) ? $wsko_data['token'] : false;

if ($token)
{
	$client = wsko_get_ga_client();
	if ($client)
	{
		$client->setAccessToken($token);
		if ($client->isAccessTokenExpired())
		{
			$client->refreshToken($token['refresh_token']);
			$token_c = $client->getAccessToken();
			if (!isset($token_c['refresh_token']))
			{
				$token_c['refresh_token'] = $token['refresh_token'];
			}
			$token = $token_c;
			if ($token)
			{
				$wsko_data['token'] = $token;
			}
			else
			{
				$wsko_data['token'] = false;
			}
			
			update_option('wsko_init', $wsko_data);
		}
	}
}
?>