<div class='wrap'>

<?php echo $this->partial('sponsors/vertical_socials'); ?>
        
<?php echo $this->getContent(); ?>

</div>