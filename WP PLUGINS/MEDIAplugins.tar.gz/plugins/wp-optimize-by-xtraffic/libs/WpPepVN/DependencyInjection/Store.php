<?php
namespace WpPepVN\DependencyInjection;

/**
 * WpPepVN\DependencyInjection\Store
 *
 */
class Store
{
    public static $instances = array();
}