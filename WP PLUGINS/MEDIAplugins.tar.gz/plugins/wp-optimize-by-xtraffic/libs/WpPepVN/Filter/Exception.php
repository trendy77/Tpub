<?php 
namespace WpPepVN\Filter;

/**
 * WpPepVN\Filter\Exception
 *
 * Exceptions thrown in WpPepVN\Filter will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}