<?php 

namespace WpPepVN\Form;

/**
 * WpPepVN\Forms\Exception
 *
 * Exceptions thrown in WpPepVN\Forms will use this class
 */
class Exception extends \WpPepVN\Exception
{

}