<?php 
namespace WpPepVN\Http\Response;

/**
 * WpPepVN\Http\Response\Exception
 *
 * Exceptions thrown in WpPepVN\Http\Response will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}
