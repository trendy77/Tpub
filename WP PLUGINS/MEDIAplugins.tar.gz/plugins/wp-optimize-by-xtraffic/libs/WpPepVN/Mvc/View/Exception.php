<?php 
namespace WpPepVN\Mvc\View;

/**
 * WpPepVN\Mvc\View\Exception
 *
 * Class for exceptions thrown by WpPepVN\Mvc\View
 */
class Exception extends \WpPepVN\Exception
{

}