<?php 

namespace WpPepVN\Validation;

/**
 * WpPepVN\Validation\Exception
 *
 * Exceptions thrown in WpPepVN\Validation\* classes will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}