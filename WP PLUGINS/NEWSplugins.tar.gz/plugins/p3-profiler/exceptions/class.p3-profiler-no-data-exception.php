<?php

if ( !defined('P3_PATH') )
	die( 'Forbidden ');

/**
 * Exception when no data is found
 *
 * @author GoDaddy.com
 * @version 1.0
 * @package P3_Profiler
 */
 class P3_Profiler_No_Data_Exception extends Exception {}
