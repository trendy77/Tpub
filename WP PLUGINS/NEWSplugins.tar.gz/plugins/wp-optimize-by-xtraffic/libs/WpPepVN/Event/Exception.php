<?php
namespace WpPepVN\Event;

/**
 * WpPepVN\Event\Exception
 *
 * Exceptions thrown in WpPepVN\Event will use this class
 */
class Exception extends \WpPepVN\Exception
{

}
