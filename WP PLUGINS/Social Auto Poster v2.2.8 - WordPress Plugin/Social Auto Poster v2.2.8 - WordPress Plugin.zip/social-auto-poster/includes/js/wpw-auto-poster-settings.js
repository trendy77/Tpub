jQuery(document).ready(function($) {	

	//twitter template
	jQuery('.tw_tweet_template').change(function() {		
		if(	jQuery('.tw_tweet_template').val() == 'custom') {		
			jQuery('#custom_template').slideDown('slow');			
		} else {
			jQuery('#custom_template').slideUp('slow');
		}
	});
	
	//url shortener
	jQuery( '.fb_url_shortener, .tw_url_shortener, .li_url_shortener, .tb_url_shortener, .dc_url_shortener, .ff_url_shortener, .ba_url_shortener' ).change( function() {
		
		var container = $( this ).attr( 'data-content' );
		//check shortner value is bitly
		if(	$( this ).val() == 'bitly' ) {		
			$( '.'+container+'_setting_input_bitly' ).slideDown( 'fast' );
		} else {
			$( '.'+container+'_setting_input_bitly' ).hide();
		}
		
		//check shortner value is shorte.st
		if(	$( this ).val() == 'shorte.st' ) {		
			$( '.'+container+'_setting_input_shortest' ).slideDown( 'fast' );
		} else {
			$( '.'+container+'_setting_input_shortest' ).hide();
		}
	});
	
	//jQuery(".nav-tab-wrapper a:first").addClass("nav-tab-active");
	//jQuery(".wpw-auto-poster-content div:first").show(); 
	
	//  When user clicks on tab, this code will be executed
    jQuery( document ).on( "click", ".nav-tab-wrapper a",function() {
        //  First remove class "active" from currently active tab
        jQuery(".nav-tab-wrapper a").removeClass('nav-tab-active');
 
        //  Now add class "active" to the selected/clicked tab
        jQuery(this).addClass("nav-tab-active");
 
        //  Hide all tab content
        jQuery(".wpw-auto-poster-tab-content").hide();
 
        //  Here we get the href value of the selected tab
        var selected_tab = $(this).attr("href");
 
        //  Show the selected tab content
        jQuery(selected_tab).show();
 		var tab_title = $(this).attr("attr-tab");
 		jQuery(".wpw-auto-poster-tab-content").removeClass('wpw-auto-poster-selected-tab');
 		$( '#wpw_auto_poster_selected_tab' ).val(tab_title);
 		
        //  At the end, we add return false so that the click on the link is not executed
        return false;
    });
    
    //Image uploader
    jQuery( document ).on( "click", ".wpw-auto-poster-uploader-button",function() {

    	var imgfield;
    	imgfield = jQuery(this).prev('input').attr('id');
    	
		if(typeof wp == "undefined" || WpwAutoPosterSettings.new_media_ui != '1' ){// check for media uploader

			tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	    	
			window.original_send_to_editor = window.send_to_editor;
			window.send_to_editor = function(html) {
				
				if(imgfield)  {
					
					var mediaurl = $('img',html).attr('src');
					$('#'+imgfield).val(mediaurl);
					tb_remove();
					imgfield = '';
					
				} else {
					
					window.original_send_to_editor(html);
					
				}
			};
	    	return false;
	    	
		} else { 
		
			var file_frame;
			//window.formfield = '';
			
			//new media uploader
			var button = jQuery(this);
	
			//window.formfield = jQuery(this).closest('.file-input-advanced');
		
			// If the media frame already exists, reopen it.
			if ( file_frame ) {
				//file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
				file_frame.open();
			  return;
			}
	
			// Create the media frame.
			file_frame = wp.media.frames.file_frame = wp.media({
				frame: 'post',
				state: 'insert',
				//title: button.data( 'uploader_title' ),
				/*button: {
					text: button.data( 'uploader_button_text' ),
				},*/
				multiple: false  // Set to true to allow multiple files to be selected
			});
	
			file_frame.on( 'menu:render:default', function(view) {
		        // Store our views in an object.
		        var views = {};
	
		        // Unset default menu items
		        view.unset('library-separator');
		        view.unset('gallery');
		        view.unset('featured-image');
		        view.unset('embed');
	
		        // Initialize the views in our view object.
		        view.set(views);
		    });
	
			// When an image is selected, run a callback.
			file_frame.on( 'insert', function() {
				// Get selected size from media uploader
				var selected_size = $('.attachment-display-settings .size').val();
				
				var selection = file_frame.state().get('selection');
				selection.each( function( attachment, index ) {
				attachment = attachment.toJSON();
					
				// Selected attachment url from media uploader
				var attachment_url = attachment.sizes[selected_size].url;
					
					if(index == 0){
						// place first attachment in field
						//window.formfield.find('.wpw-auto-poster-upload-file-link').val(attachment.url);
						$('#'+imgfield).val(attachment_url);
						
					} else{
						$('#'+imgfield).val(attachment_url);
					}
				});
			});
	
			// Finally, open the modal
			file_frame.open();
			
		}
    });
    
    //reset confirmation
    jQuery( document ).on( "click", ".wpw-auto-poster-reset-button",function() {
    	
    	var ans;
		ans = confirm( WpwAutoPosterSettings.confirmmsg );

		if(ans){
			return true;
		} else {
			return false;
		}
    	
    });
    
    //posted logs delete confirmation
    jQuery( document ).on( "click", ".wpw-auto-poster-logs-delete",function() {
    	
    	var ans;
		ans = confirm( WpwAutoPosterSettings.deleteconfirmmsg );

		if(ans){
			return true;
		} else {
			return false;
		}
    	
    });
    
    //add more account details for facebook
	jQuery( document ).on( 'click', '.wpw-auto-poster-add-more-fb-account', function() {
		var jQueryfirst = jQuery(this).parents('.wpw-auto-poster-facebook-settings').find('.wpw-auto-poster-facebook-account-details:last');
		var last_row_id = parseInt( jQueryfirst.attr( 'data-row-id' ) );
		last_row_id 	= last_row_id + 1;
		
		var clone_row = jQueryfirst.clone();
		
		clone_row.insertAfter(jQueryfirst).show();
		clone_row.find('.wpw-grant-reset-data').html('');
		
	 	jQuery(this).parents('.wpw-auto-poster-facebook-settings').find('.wpw-auto-poster-facebook-account-details:last .wpw-auto-poster-facebook-app-id').attr( 'name', 'wpw_auto_poster_options[facebook_keys]['+last_row_id+'][app_id]' ).val('');
	 	jQuery(this).parents('.wpw-auto-poster-facebook-settings').find('.wpw-auto-poster-facebook-account-details:last .wpw-auto-poster-facebook-app-secret').attr( 'name', 'wpw_auto_poster_options[facebook_keys]['+last_row_id+'][app_secret]' ).val('');
	 	jQuery(this).parents('.wpw-auto-poster-facebook-settings').find('.wpw-auto-poster-facebook-account-details:last .wpw-auto-poster-facebook-remove').show();
	 	jQuery(this).parents('.wpw-auto-poster-facebook-settings').find('.wpw-auto-poster-facebook-account-details:last').attr( 'data-row-id', last_row_id );
	 	return false;
	});
	
	//delete account details for facebook
	jQuery( document ).on( 'click', '.wpw-auto-poster-delete-fb-account', function() {
		
		var jQueryparent = jQuery(this).parents('.wpw-auto-poster-facebook-account-details');
		jQueryparent.remove();
		
		return false;
	});
    
    //add more account details for twitter
	jQuery( document ).on( 'click', '.wpw-auto-poster-add-more-account', function() {
		var jQueryfirst = jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last');
		var last_row_id = parseInt( jQueryfirst.attr( 'data-row-id' ) );
		last_row_id 	= last_row_id + 1;
		jQueryfirst.clone().insertAfter(jQueryfirst).show();
	 	jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last .wpw-auto-poster-twitter-consumer-key').attr( 'name', 'wpw_auto_poster_options[twitter_keys]['+last_row_id+'][consumer_key]' ).val('');
	 	jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last .wpw-auto-poster-twitter-consumer-secret').attr( 'name', 'wpw_auto_poster_options[twitter_keys]['+last_row_id+'][consumer_secret]' ).val('');
	 	jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last .wpw-auto-poster-twitter-oauth-token').attr( 'name', 'wpw_auto_poster_options[twitter_keys]['+last_row_id+'][oauth_token]' ).val('');
	 	jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last .wpw-auto-poster-twitter-oauth-secret').attr( 'name', 'wpw_auto_poster_options[twitter_keys]['+last_row_id+'][oauth_secret]' ).val('');
	 	jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last .wpw-auto-poster-twitter-remove').show();
	 	jQuery(this).parents('.wpw-auto-poster-twitter-settings').find('.wpw-auto-poster-twitter-account-details:last').attr( 'data-row-id', last_row_id );
	 	return false;
	});

    //delete account details for twitter
	jQuery( document ).on( 'click', '.wpw-auto-poster-delete-account', function() {
		
		var jQueryparent = jQuery(this).parents('.wpw-auto-poster-twitter-account-details');
		jQueryparent.remove();
		
		return false;
	});
    
	//on click of view details from posted logs list
	jQuery( document ).on( "click", ".wpw-auto-poster-meta-view-details", function() {
		
		var popupcontent = jQuery(this).parent().find( '.wpw-auto-poster-popup-content' );
		popupcontent.show();
		jQuery(this).parent().find( '.wpw-auto-poster-popup-overlay' ).show();
		jQuery('html, body').animate({ scrollTop: popupcontent.offset().top - 80 }, 500);
		
	});
	
	//on click of close button or overlay
	jQuery( document ).on( "click", ".wpw-auto-poster-popup-overlay, .wpw-auto-poster-close-button", function() {
		
		jQuery( '.wpw-auto-poster-popup-content' ).hide();
		jQuery( '.wpw-auto-poster-popup-overlay' ).hide();
	});
	
	// apply chosen for posting logs
	jQuery(".wpw-auto-poster-form select").each(function (){
		jQuery(this).css('width','300px').chosen({search_contains:true});
	});
	
	$( document ).on( 'change', '.wpw-auto-poster-schedule-option', function() {
		var schedule = $( this ).val();
		
		$( '.wpw-auto-poster-custom-schedule-wrap' ).hide();
		if( schedule == 'daily' ) {
			
			$( '.wpw-auto-poster-custom-schedule-wrap' ).show();
		}
		
		if($('#wpw_auto_poster_random_posting').is(':checked')){
			$('.wpw-auto-poster-schedule-time').hide();
		}
		
		// Show / hide schedule limit option
		$('.wpw-auto-poster-schedule-limit').show();
		if( schedule == '' ) {
			$('.wpw-auto-poster-schedule-limit').hide();
		}
		
	});
	
	// Posting type radio button
	$( document ).on( 'click', '.wpw-auto-poster-random-posting', function() {
		if( $(this).val() == 1 ){
			$('.wpw-auto-poster-schedule-time').hide();
		} else {
			$('.wpw-auto-poster-schedule-time').show();
		}
	});

	$( document ).on( 'change', '#wpw_auto_poster_li_type_post_method', function() {
					
		$( this ).parent().parent().find( '.wpw-auto-poster-li-posting-wrap' ).hide();
		var posting_type	= $( this ).val();
		$( this ).parent().parent().find('.wpw-auto-poster-li-' + posting_type + '-posting').show();
		//$( '.wpw-auto-poster-li-' + posting_type + '-posting' ).show();
	});
	
});