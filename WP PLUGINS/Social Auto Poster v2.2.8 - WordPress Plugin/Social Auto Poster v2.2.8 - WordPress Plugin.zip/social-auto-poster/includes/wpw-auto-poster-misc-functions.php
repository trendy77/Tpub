<?php

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Misc Functions
 * 
 * 
 * @package Social Auto Poster
 * @since 1.0.0
 */

/**
 * Get Settings From Option Page
 * 
 * Handles to return all settings value
 * 
 * @package Social Auto Poster
 * @since 1.0.0
 */
function wpw_auto_poster_settings() {
	
	$settings = is_array(get_option('wpw_auto_poster_options')) ? get_option('wpw_auto_poster_options') : array();
	
	return $settings;
}

/**
 * Initialize some intial setup
 * 
 * @package Social Auto Poster
 * @since 1.0.0
 */
function wpw_auto_poster_initialize() {
	
	global $wpw_auto_poster_options;
	
	// Facebook Application ID and Secret
	$fb_apps = wpw_auto_poster_get_fb_apps();
	
	if( !empty($_GET['wpw_fb_app_id']) ) {
		$fb_app_id = $_GET['wpw_fb_app_id'];
	} else {
		$fb_app_keys = array_keys($fb_apps);
		$fb_app_id = reset( $fb_app_keys );
	}
	$fb_app_secret 	= isset( $fb_apps[$fb_app_id] ) ? $fb_apps[$fb_app_id] 	: '';
	
	if( !defined( 'WPW_AUTO_POSTER_FB_APP_ID' ) ) {
		define( 'WPW_AUTO_POSTER_FB_APP_ID', $fb_app_id );
	}
	if( !defined( 'WPW_AUTO_POSTER_FB_APP_SECRET' ) ) {
		define( 'WPW_AUTO_POSTER_FB_APP_SECRET', $fb_app_secret );
	}
	
	// Defining the session variables
	if( !defined( 'WPW_AUTO_POSTER_FB_SESS1' ) ) {
		define( 'WPW_AUTO_POSTER_FB_SESS1', 'fb_'.WPW_AUTO_POSTER_FB_APP_ID.'_code' );
	}
	if( !defined( 'WPW_AUTO_POSTER_FB_SESS2' ) ) {
		define( 'WPW_AUTO_POSTER_FB_SESS2', 'fb_'.WPW_AUTO_POSTER_FB_APP_ID.'_access_token' );
	}
	if( !defined( 'WPW_AUTO_POSTER_FB_SESS3' ) ) {
		define( 'WPW_AUTO_POSTER_FB_SESS3', 'fb_'.WPW_AUTO_POSTER_FB_APP_ID.'_user_id' );
	}
	if( !defined( 'WPW_AUTO_POSTER_FB_SESS4' ) ) {
		define( 'WPW_AUTO_POSTER_FB_SESS4', 'fb_'.WPW_AUTO_POSTER_FB_APP_ID.'_state' );
	}
	
	// Twitter Consumer Key and Secret
	$tw_consumer_key = isset( $wpw_auto_poster_options['twitter_keys'] ) && isset( $wpw_auto_poster_options['twitter_keys']['0'] ) ? $wpw_auto_poster_options['twitter_keys']['0']['consumer_key'] : '';
	$tw_consumer_secret = isset( $wpw_auto_poster_options['twitter_keys'] ) && isset( $wpw_auto_poster_options['twitter_keys']['0'] ) ? $wpw_auto_poster_options['twitter_keys']['0']['consumer_secret'] : '';
	$tw_auth_token = isset( $wpw_auto_poster_options['twitter_keys'] ) && isset( $wpw_auto_poster_options['twitter_keys']['0'] ) ? $wpw_auto_poster_options['twitter_keys']['0']['oauth_token'] : '';
	$tw_auth_token_secret = isset( $wpw_auto_poster_options['twitter_keys'] ) && isset( $wpw_auto_poster_options['twitter_keys']['0'] ) ? $wpw_auto_poster_options['twitter_keys']['0']['oauth_secret'] : '';
	
	if( !defined( 'WPW_AUTO_POSTER_TW_CONS_KEY' ) ) {
		define( 'WPW_AUTO_POSTER_TW_CONS_KEY', $tw_consumer_key );
	}
	if( !defined( 'WPW_AUTO_POSTER_TW_CONS_SECRET' ) ) {
		define( 'WPW_AUTO_POSTER_TW_CONS_SECRET', $tw_consumer_secret );
	}
	if( !defined( 'WPW_AUTO_POSTER_TW_AUTH_TOKEN' ) ) {
		define( 'WPW_AUTO_POSTER_TW_AUTH_TOKEN', $tw_auth_token );
	}
	if( !defined( 'WPW_AUTO_POSTER_TW_AUTH_SECRET' ) ) {
		define( 'WPW_AUTO_POSTER_TW_AUTH_SECRET', $tw_auth_token_secret );
	}
	
	//LinkedIn Consumer Key and Secret
	$li_app_id = isset( $wpw_auto_poster_options[ 'linkedin_app_id'] ) ? $wpw_auto_poster_options[ 'linkedin_app_id'] : '';
	$li_app_secret = isset( $wpw_auto_poster_options[ 'linkedin_app_secret'] ) ? $wpw_auto_poster_options[ 'linkedin_app_secret'] : '';
	
	if( !defined( 'WPW_AUTO_POSTER_LI_APP_ID' ) ) {
		define( 'WPW_AUTO_POSTER_LI_APP_ID', $li_app_id);
	}
	if( !defined( 'WPW_AUTO_POSTER_LI_APP_SECRET' ) ) {
		define( 'WPW_AUTO_POSTER_LI_APP_SECRET', $li_app_secret );
	}
	if( !defined( 'WPW_AUTO_POSTER_LINKEDIN_PORT_HTTP' ) ) { //http port value
	 	define( 'WPW_AUTO_POSTER_LINKEDIN_PORT_HTTP', '80' );
	}
	if( !defined( 'WPW_AUTO_POSTER_LINKEDIN_PORT_HTTP_SSL' ) ) { //ssl port value
	  	define( 'WPW_AUTO_POSTER_LINKEDIN_PORT_HTTP_SSL', '443' );
	}
	
	//Tumblr Consumer Key and Secret
	$tb_consumer_key = isset( $wpw_auto_poster_options[ 'tumblr_consumer_key' ] ) ? $wpw_auto_poster_options[ 'tumblr_consumer_key' ] : '';
	$tb_consumer_secret = isset( $wpw_auto_poster_options[ 'tumblr_consumer_secret' ] ) ? $wpw_auto_poster_options[ 'tumblr_consumer_secret' ] : '';
	
	if( !defined( 'WPW_AUTO_POSTER_TB_CONS_KEY' ) ) {
		define( 'WPW_AUTO_POSTER_TB_CONS_KEY', $tb_consumer_key );
	}
	if( !defined( 'WPW_AUTO_POSTER_TB_CONS_SECRET' ) ) {
		define( 'WPW_AUTO_POSTER_TB_CONS_SECRET', $tb_consumer_secret );
	}
	
	//Delicious Username and password
	$delicious_username = isset( $wpw_auto_poster_options[ 'delicious_username' ] ) ? $wpw_auto_poster_options[ 'delicious_username' ] : '';
	$delicious_password = isset( $wpw_auto_poster_options[ 'delicious_password' ] ) ? $wpw_auto_poster_options[ 'delicious_password' ] : '';
	
	if( !defined( 'WPW_AUTO_POSTER_DC_USERNAME' ) ) {
		define( 'WPW_AUTO_POSTER_DC_USERNAME', $delicious_username );
	}
	if( !defined( 'WPW_AUTO_POSTER_DC_PASSWORD' ) ) {
		define( 'WPW_AUTO_POSTER_DC_PASSWORD', base64_decode( $delicious_password ) );
	}
	
	//BufferApp Client id and secret
	$ba_client_id = isset( $wpw_auto_poster_options[ 'bufferapp_client_id' ] ) ? $wpw_auto_poster_options['bufferapp_client_id'] : '';
	$ba_client_secret = isset( $wpw_auto_poster_options['bufferapp_client_secret' ] ) ? $wpw_auto_poster_options['bufferapp_client_secret'] : '';
	
	if( !defined( 'WPW_AUTO_POSTER_BA_CLIENT_ID' ) ) {
		define( 'WPW_AUTO_POSTER_BA_CLIENT_ID', $ba_client_id );
	}
	if( !defined( 'WPW_AUTO_POSTER_BA_CLIENT_SECRET' ) ) {
		define( 'WPW_AUTO_POSTER_BA_CLIENT_SECRET', $ba_client_secret );
	}
}

/**
 * Get Social Auto poster Screen ID
 * 
 * Handles to get social auto poster screen id
 * 
 * @package Social Auto Poster
 * @since 1.8.1
 */
function wpw_auto_poster_get_sap_screen_id() {
	
	$wpsap_screen_id = sanitize_title( __( 'Social Auto Poster', 'wpwautoposter' ) );
	return apply_filters( 'wpw_auto_poster_get_sap_screen_id', $wpsap_screen_id );
}

/**
 * Get Social Auto poster Screen ID
 * 
 * Handles to get social auto poster screen id
 * 
 * @package Social Auto Poster
 * @since 2.1.1
 */
function wpw_auto_poster_get_fb_apps() {
	
	global $wpw_auto_poster_options;
	
	$fb_apps	= array();
	$fb_keys 	= !empty($wpw_auto_poster_options['facebook_keys']) ? $wpw_auto_poster_options['facebook_keys'] : array();
	
	if( !empty( $fb_keys ) ) {
		
		foreach ( $fb_keys as $fb_key_id => $fb_key_data ){
			
			if( !empty( $fb_key_data['app_id'] ) && !empty($fb_key_data['app_secret']) ) {
				$fb_apps[ $fb_key_data['app_id'] ] = $fb_key_data['app_secret'];
			}
			
		} // End of for each
	} // End of main if
	
	return $fb_apps;
}

/**
 * Get Social Auto poster Screen ID
 * 
 * Handles to get social auto poster screen id
 * 
 * @package Social Auto Poster
 * @since 2.2.0
 */
function wpw_auto_poster_get_fb_accounts( $data_type = false ) {
	
	// Taking some defaults
	$res_data = array();
	
	// Get stored fb app grant data
	$wpw_auto_poster_fb_sess_data = get_option( 'wpw_auto_poster_fb_sess_data' );
	
	if( is_array( $wpw_auto_poster_fb_sess_data ) && !empty($wpw_auto_poster_fb_sess_data) ) {
		
		foreach ( $wpw_auto_poster_fb_sess_data as $fb_sess_key => $fb_sess_data ) {
			
			$fb_sess_acc 	= isset( $fb_sess_data['wpw_auto_poster_fb_user_accounts']['auth_accounts'] ) 	? $fb_sess_data['wpw_auto_poster_fb_user_accounts']['auth_accounts'] 	: array();
			$fb_sess_token 	= isset( $fb_sess_data['wpw_auto_poster_fb_user_accounts']['auth_tokens'] ) 	? $fb_sess_data['wpw_auto_poster_fb_user_accounts']['auth_tokens'] 		: array();
			
			// Retrives only App Users
			if( $data_type == 'all_app_users' ) {
				
				// Loop of account and merging with page id and app key
				foreach ( $fb_sess_acc as $fb_page_id => $fb_page_name ) {
					$res_data[$fb_sess_key][] = $fb_page_id .'|'. $fb_sess_key;
				}
				
			} elseif( $data_type == 'all_app_users_with_name' ) {
				
				// Loop of account and merging with page id and app key
				foreach ( $fb_sess_acc as $fb_page_id => $fb_page_name ) {
					$res_data[$fb_sess_key][$fb_page_id .'|'. $fb_sess_key] = $fb_page_name;
				}
				
			} elseif ( $data_type == 'app_users' ) {
				
				$res_data[$fb_sess_key] = ( !empty($fb_sess_acc) && is_array($fb_sess_acc) ) ? array_keys( $fb_sess_acc ) : array();
				
			} elseif ( $data_type == 'all_auth_tokens' ) {
				
				// Loop of tokens and merging with page id and app key
				foreach ( $fb_sess_token as $fb_sess_token_id => $fb_sess_token_data ) {
					$res_data[$fb_sess_token_id .'|'. $fb_sess_key] = $fb_sess_token_data;
				}
				
			} elseif ( $data_type == 'auth_tokens' ) {
				
				// Merging the array
				$res_data = $res_data + $fb_sess_token;
				
			} elseif ( $data_type == 'all_accounts' ) {
				
				// Loop of account and merging with page id and app key
				foreach ( $fb_sess_acc as $fb_page_id => $fb_page_name ) {
					$res_data[$fb_page_id .'|'. $fb_sess_key] = $fb_page_name;
				}
				
			} else {
				
				// Merging the array
				$res_data = $res_data + $fb_sess_acc;
				
			}
		}
	}
	
	return $res_data;
}

/**
 * Check Extra Security
 * 
 * Handles to check extra security
 * 
 * @package Social Auto Poster
 * @since 2.1.1
 */
function wpw_auto_poster_extra_security( $post_id ) {
	
	$extra_security	= false;
	
	if( ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] ) ) {
		$extra_security	= true;
	}
	
	// 
	$wpw_auto_poster_set_option = get_option( 'wpw_auto_poster_options' );
	
	if( ( isset( $wpw_auto_poster_set_option['autopost_thirdparty_plugins'] ) && $wpw_auto_poster_set_option['autopost_thirdparty_plugins'] == 1 ) ) {
		
		$extra_security	= false;
	}
	
	$extra_security = apply_filters( 'wpw_auto_poster_extra_security', $extra_security, $post_id );
	
	return $extra_security;
}