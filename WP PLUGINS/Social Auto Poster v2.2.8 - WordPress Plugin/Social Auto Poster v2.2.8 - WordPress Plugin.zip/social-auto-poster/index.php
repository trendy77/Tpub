<?php
/* Silence is golden */
?>