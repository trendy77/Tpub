===== Social Auto Poster =====
Author: wpweb.co.in
Donate link: http://wpweb.co.in/
Requires at least: 3.4
Tested up to: 4.2.1
Tags: facebook, autopost, social, poster, blogpost

Social Auto Poster lets you automatically post all your content to several different social networks.

See http://wpweb.co.in/documents/social-auto-poster/ for full documentation.

== Installation Steps == 

1) Download the Social Auto Poster Plugin.
2) Unzip the file and upload the social-auto-poster folder to the /wp-content/plugins/ directory using your FTP application.
3) Activate the Social Auto Poster plugin through the 'Plugins' menu in WordPress.
4) Configure the plugin by going to the Social Auto Poster > Settings within WordPress admin.


== Upgrade Notice ==
Please upgrade now to use the latest features.