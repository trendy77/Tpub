<?php echo $this->partial('notice'); ?>

<div class="wrap">
	<div class="bootstrap-wppepvn">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-8">
					<?php echo $this->getContent(); ?>
				</div>
				<div class="col-xs-12 col-sm-4">
					<?php echo $this->partial('sponsors/vertical_socials'); ?>
				</div>
				
			</div>
		</div>
	</div>
</div>