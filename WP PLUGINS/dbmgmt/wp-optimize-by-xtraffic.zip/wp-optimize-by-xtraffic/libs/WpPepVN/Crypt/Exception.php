<?php 
namespace WpPepVN\Crypt;

/**
 * WpPepVN\Crypt\Exception
 *
 * Exceptions thrown in WpPepVN\Crypt use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}
