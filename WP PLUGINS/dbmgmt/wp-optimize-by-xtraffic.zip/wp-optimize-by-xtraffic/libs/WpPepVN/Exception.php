<?php
namespace WpPepVN;

/**
 * WpPepVN\Exception
 *
 * All framework exceptions should use or extend this exception
 */
class Exception extends \Exception
{

}