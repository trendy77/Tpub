<?php 
namespace WpPepVN\Http\Request;

/**
 * WpPepVN\Http\Request\Exception
 *
 * Exceptions thrown in WpPepVN\Http\Request will use this class
 *
 */
class Exception extends \WpPepVN\Exception
{

}